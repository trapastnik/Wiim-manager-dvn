# WiiM Web Control

Веб-система для управления несколькими медиаплеерами WiiM Mini в локальной сети.

![Version](https://img.shields.io/badge/version-2.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)

## ⚡ Быстрый старт

```bash
# 1. Установить зависимости
npm install

# 2. Настроить конфигурацию
cp .env.example .env
# Отредактируйте .env и укажите IP адрес WiiM

# 3. Запустить сервер
npm start

# 4. Открыть в браузере
http://localhost:3000
```

## 🎯 Основные возможности

- **Мультиплеер** - Управление несколькими WiiM плеерами одновременно
- **Группы плееров** - Создание групп для синхронного запуска
- **Медиа библиотека** - Загрузка и управление аудио файлами
- **Режим повтора** - Бесшовное зацикливание треков
- **Сканирование сети** - Автоматический поиск WiiM устройств
- **Демо-режим** - Тестирование без реальных устройств

## 📁 Структура проекта

```
wiim/
├── server.js              # Express сервер
├── wiim-client.js         # WiiM API клиент
├── network-scanner.js     # Сетевой сканер
├── storage.js             # Хранилище данных
├── scan.js                # Утилита сканирования
├── public/                # Веб-интерфейс
│   ├── index.html
│   ├── style.css
│   └── app.js            # Frontend (2270 строк)
├── docs/                  # 📚 Полная документация
└── old/                   # Архив старых версий
```

## 📚 Документация

Вся документация находится в папке **[`docs/`](docs/)**.

### Для начала работы:
- [Быстрый старт](docs/QUICK_START.md)
- [Установка](docs/INSTALL.md)
- [Список функций](docs/FEATURES.md)

### Для продвинутых:
- [Работа с группами](docs/MULTI-PLAYER-GUIDE.md)
- [Структура app.js](docs/APP_STRUCTURE.md)
- [Диагностика](docs/DIAGNOSTICS-GUIDE.md)

**➡️ [Полный список документации](docs/README.md)**

## 🔧 Основные команды

```bash
npm start          # Запуск сервера
npm run dev        # Режим разработки с auto-reload
node scan.js       # Сканирование сети для поиска WiiM
```

## 🌐 API Endpoints

```bash
GET  /api/status                    # Статус всех плееров
POST /api/players/scan              # Сканирование сети
POST /api/players/:id/play          # Воспроизведение
POST /api/players/:id/volume        # Установка громкости
POST /api/media/upload              # Загрузка файла
```

**➡️ [Полная документация API](docs/FEATURES.md#api)**

## 💡 Пример использования

```javascript
// Синхронный запуск группы плееров
const group = {
  name: "Гостиная",
  players: ["player1", "player2"]
};
await playGroup(group.id);

// Управление громкостью группы
await setGroupVolume(group.id, 75);
```

## 🛠️ Технологии

- **Backend**: Node.js, Express
- **Frontend**: Vanilla JS (ES6+)
- **API**: WiiM HTTP API
- **Storage**: localStorage + JSON files

## 📝 Changelog

- **v2.0.0** - Мультиплеер, группы, демо-режим
- **v1.0.0** - Базовое управление одним плеером

**➡️ [Полная история изменений](docs/CHANGELOG.md)**

## 🔐 Безопасность

⚠️ **Только для локальной сети!** Не предназначен для публичного доступа.

- Нет аутентификации
- Принимает самоподписанные SSL сертификаты
- [Рекомендации по безопасности](docs/SECURITY_RECOMMENDATIONS.md)

## 📞 Поддержка

- **Проблемы?** → [Диагностика](docs/DIAGNOSTICS-GUIDE.md)
- **Вопросы?** → [Issues](https://github.com/yourusername/wiim/issues)

## 📄 Лицензия

MIT License - свободно используйте для личных и коммерческих проектов.

---

**Сделано с ❤️ для управления WiiM Mini плеерами**
